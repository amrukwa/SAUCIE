import numpy as np
import pytest
from sklearn.datasets import make_blobs

from divae.plot import contour_matrix


np.random.seed(1234)


def data():
    return make_blobs(
        n_samples=100,
        n_features=4,
        centers=2,
        random_state=42,
    )


def test_contour_matrix_works_manual():
    # Just check if doesn't fail, no content check
    X, y = data()
    fig = contour_matrix(X, y)
    fig.write_html('dummy.html')


def test_partition_image_manual():
    # Just check if doesn't fail, no content check
    """Check if the skimage label coloring follows label order"""
    import skimage
    from divae.__main__ import colors, visualize

    def visualize_plotly(label, xy, shape=None):
        """Create RGB map of labels over with given coordinates"""
        x, y = xy.T
        if shape is None:
            shape = np.max(y) + 1, np.max(x) + 1
        y = y.max() - y
        label = label - label.min() + 1
        label_map = np.zeros(shape) * np.nan
        label_map[y, x] = label
        colors_ = [
            f"rgb({int(255*r)},{int(255*g)},{int(255*b)})"
            for _, (r, g, b) in zip(np.unique(label), colors())
        ]

        import plotly.express as px
        fig = px.imshow(label_map[::-1], color_continuous_scale=colors_)

        return fig

    size = 13
    upper_bound = 6

    # original
    some_image = np.random.randint(upper_bound, size=(size, size))
    skimage.io.imsave('dummy_1.png', some_image)

    # skimage
    label = some_image.ravel()
    xy = np.indices(some_image.shape).reshape(2, -1)
    xy = np.moveaxis(xy, 0, -1)
    img = visualize(label, xy)
    skimage.io.imsave('dummy_2.png', img)

    # plotly
    fig = visualize_plotly(label, xy)
    fig.write_image('dummy_3.png')


def test_partition_image():
    """Check if the skimage label coloring follows label order"""
    import skimage
    from divae.__main__ import colors, visualize

    size = 13
    upper_bound = 6

    some_image = np.random.randint(upper_bound, size=(size, size))

    labels = some_image.ravel()
    xy = np.indices(some_image.shape).reshape(2, -1)
    xy = np.moveaxis(xy, 0, -1)

    expected_colors = {
        label: np.array([r,g,b], dtype=float)
        for label, (r,g,b)
        in zip(np.unique(labels), colors())
    }
    
    img = visualize(labels, xy)
    # there is a flip of the image in the visualization function
    img = np.moveaxis(img, 0, 1)

    for i in range(size):
        for j in range(size):
            label = some_image[i, j]
            expected_color = expected_colors[label]
            actual_color = img[i, j]
            np.testing.assert_almost_equal(actual_color, expected_color)
