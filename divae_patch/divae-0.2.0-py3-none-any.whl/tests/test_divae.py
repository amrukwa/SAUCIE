import io
import pickle

import numpy as np
np.random.seed(1234)

import pytest
import tensorflow as tf
from divik.feature_extraction import (
    HistogramEqualization,
)
from divae.divae import (
    LearningRateScheduler,
    VAE,
    AutoGMM,
    DiVAE,
)
from sklearn.datasets import make_blobs
from sklearn.base import clone
from skimage.exposure import equalize_hist


tf.random.set_seed(1234)


def data_vae():
    data = make_blobs(
        n_samples=10000,
        n_features=20,
        centers=2,
        random_state=42,
    )[0]
    data = data - np.min(data)
    return data


def data_gmm():
    return make_blobs(
        n_samples=100,
        n_features=2,
        centers=2,
        random_state=42,
    )[0]


# TODO: Merge this upstream to divik
def test_hist_equalization():
    X = data_vae()

    y = HistogramEqualization(n_bins=1).fit_transform(X)
    y_expected = np.hstack([
        equalize_hist(X[:, i], nbins=1).reshape(-1, 1)
        for i in range(X.shape[1])
    ])
    assert y_expected.shape == X.shape
    assert y.shape == X.shape
    np.testing.assert_array_equal(y_expected, y)

    y = HistogramEqualization(n_bins=2).fit_transform(X)
    y_expected = np.hstack([
        equalize_hist(X[:, i], nbins=2).reshape(-1, 1)
        for i in range(X.shape[1])
    ])
    assert y_expected.shape == X.shape
    assert y.shape == X.shape
    np.testing.assert_array_equal(y_expected, y)

    y = HistogramEqualization(n_bins=256).fit_transform(X)
    y_expected = np.hstack([
        equalize_hist(X[:, i], nbins=256).reshape(-1, 1)
        for i in range(X.shape[1])
    ])
    assert y_expected.shape == X.shape
    assert y.shape == X.shape
    np.testing.assert_array_equal(y_expected, y)


def test_lr_scheduler():
    schd = LearningRateScheduler(epoch_max=4, lr_min=1, lr_max=2)
    lr = [schd(i, 0) for i in range(4)]
    np.testing.assert_array_equal(lr, [1, 2, 2, 1])

    schd = LearningRateScheduler(epoch_max=5, lr_min=1, lr_max=2)
    lr = [schd(i, 0) for i in range(5)]
    np.testing.assert_array_equal(lr, [1, 2, 2, 1.5, 1])

    schd = LearningRateScheduler(epoch_max=5, lr_min=1, lr_max=1)
    lr = [schd(i, 0) for i in range(5)]
    np.testing.assert_array_equal(lr, [1, 1, 1, 1, 1])

    import gin
    gin.bind_parameter('LearningRateScheduler.epoch_max', 5)
    gin.bind_parameter('LearningRateScheduler.lr_min', 1)
    gin.bind_parameter('LearningRateScheduler.lr_max', 2)
    schd = LearningRateScheduler()
    clbk = schd.as_callback()
    assert isinstance(clbk, tf.keras.callbacks.LearningRateScheduler)


def test_VAE_compresses_data():
    data = data_vae()
    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=2)
    vae.fit(data)
    encoded = vae.transform(data)
    assert not np.isnan(encoded).any()
    assert encoded.shape[1] == 2


def test_VAE_yields_stable_results_without_training():
    data = data_vae()
    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=0, random_state=42)
    vae.fit(data)
    encoded1 = vae.transform(data)

    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=0, random_state=42)
    vae.fit(data)
    encoded2 = vae.transform(data)
    np.testing.assert_array_equal(encoded1, encoded2)

    vae = VAE(
        intermediate_dim=5, latent_dim=2, epochs=0, random_state=42,
        equalize_histogram=True
    )
    vae.fit(data)
    encoded1 = vae.transform(data)

    vae = VAE(
        intermediate_dim=5, latent_dim=2, epochs=0, random_state=42,
        equalize_histogram=True
    )
    vae.fit(data)
    encoded2 = vae.transform(data)

    np.testing.assert_array_equal(encoded1, encoded2)


def test_VAE_yields_stable_results_with_training():
    data = data_vae()
    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=4, random_state=42, shuffle=False)
    vae.fit(data)
    encoded1 = vae.transform(data)

    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=4, random_state=42, shuffle=False)
    vae.fit(data)
    encoded2 = vae.transform(data)

    np.testing.assert_array_equal(encoded1, encoded2)

def test_VAE_is_clonable():
    data = data_vae()
    vae = VAE(intermediate_dim=5, latent_dim=2, epochs=4, random_state=42, shuffle=False)
    vae.fit(data)
    encoded1 = vae.transform(data)

    vae1 = clone(vae)
    vae1.fit(data)
    encoded2 = vae1.transform(data)

    np.testing.assert_array_equal(encoded1, encoded2)


def test_VAE_5_layer_compresses_data():
    data = data_vae()
    vae = VAE(intermediate_dim=(5, 3), latent_dim=2, epochs=2, random_state=42)
    vae.fit(data)
    encoded = vae.transform(data)
    assert not np.isnan(encoded).any()
    assert encoded.shape[1] == 2


def test_gmm_labels_data():
    data = data_gmm()
    gmm = AutoGMM(max_clusters=5, method='knee', random_state=42).fit(data)
    assert gmm.n_clusters_ is not None
    assert gmm.labels_.size == data.shape[0]
    assert gmm.n_clusters_ == 2

    gmm = AutoGMM(max_clusters=5, method='bayes_factor', random_state=42).fit(data)
    assert gmm.n_clusters_ is not None
    assert gmm.labels_.size == data.shape[0]
    assert gmm.n_clusters_ == 2

    gmm = AutoGMM(max_clusters=5, method='youden', random_state=42).fit(data)
    assert gmm.n_clusters_ is not None
    assert gmm.labels_.size == data.shape[0]
    assert gmm.n_clusters_ == 2

    gmm = AutoGMM(max_clusters=5, early_stopping=2, random_state=42).fit(data)
    assert gmm.n_clusters_ is not None
    assert gmm.labels_.size == data.shape[0]
    assert gmm.n_clusters_ == 2


def test_divae_labels_data():
    data = data_vae()
    ctr = DiVAE(
        auto_gmm=AutoGMM(max_clusters=5, random_state=42),
        vae=VAE(intermediate_dim=5, latent_dim=2, epochs=2, random_state=42),
        minimal_size=100,
        rejection_size=5,
        random_state=42,
        n_jobs=1,
        verbose=True,
    )
    ctr.fit(data)
    assert ctr.n_clusters_ is not None
    assert ctr.labels_.size == data.shape[0]
    assert ctr.depth_ > 0
    assert ctr.depth_ < 5
    unique_labels, cnt = np.unique(ctr.labels_, return_counts=True)
    assert not (cnt < 5).any()
    assert len(unique_labels) < 20


def test_divae_is_picklable():
    obj = DiVAE(auto_gmm=AutoGMM(), vae=VAE())
    with io.BytesIO() as f:
        pickle.dump(obj, f)
        f.seek(0)
        obj2 = pickle.load(f)
    assert str(obj) == str(obj2)  # All classes inherit from BaseEstimator


def test_divae_pickling_restores_tf_graph():
    data = data_vae()
    obj = DiVAE(
        auto_gmm=AutoGMM(max_clusters=5, random_state=42),
        vae=VAE(intermediate_dim=5, latent_dim=2, epochs=2, random_state=42),
        minimal_size=100,
        rejection_size=5,
        random_state=42,
        n_jobs=1,
        verbose=True,
    ).fit(data)
    labels1 = obj.predict(data)
    with io.BytesIO() as f:
        pickle.dump(obj, f)
        f.seek(0)
        obj2 = pickle.load(f)
    labels2 = obj2.predict(data)
    np.testing.assert_array_equal(labels1, labels2)


from divae.divae import _intensity_distances

def test_intensity_distances():
    radius = 3

    X = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    xy = np.array([[0, 0], [1, 1], [0, 1]])

    x, y = xy.T
    x = x - x.min() + radius
    y = y - y.min() + radius
    cube = np.nan * np.zeros((y.max() + radius + 1, x.max() + radius + 1, X.shape[1]))
    cube[y, x] = X

    assert cube.shape == (8, 8, 3)
    np.testing.assert_array_equal(cube[3, 3], [1, 2, 3])
    np.testing.assert_array_equal(cube[4, 4], [4, 5, 6])
    np.testing.assert_array_equal(cube[4, 3], [7, 8, 9])  # mind the dim invertion

    kernel_size = 2 * radius + 1
    indices = np.indices((kernel_size, kernel_size)) - radius

    padded_dist_cube = _intensity_distances(cube, indices, x, y, "euclidean")
    assert padded_dist_cube.shape == (8, 8, 49)
    # Distance to itself must be zero, own index is in the middle of indices
    assert padded_dist_cube[3, 3, 49//2] == 0
    assert padded_dist_cube[4, 4, 49//2] == 0
    assert padded_dist_cube[4, 3, 49//2] == 0
    # X-axis left neighbor
    assert padded_dist_cube[4, 4, 49//2 - 1] == np.sqrt(27)
    # X-axis right neighbor
    assert padded_dist_cube[4, 3, 49//2 + 1] == np.sqrt(27)
    # Y-axis upper neighbor
    assert padded_dist_cube[4, 3, 49//2 - kernel_size] == np.sqrt(3*(6**2))


from divae.divae import SpatialSmoothing

def test_bilateral_filter():
    # TODO: Improve tests
    f = SpatialSmoothing()
    X = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    xy = np.array([[0, 0], [1, 1], [0, 1]])
    X_trans = f.transform(X=X, xy=xy)

    assert X_trans.shape == X.shape
    np.testing.assert_array_less([1, 2, 3], X_trans[0])
    np.testing.assert_array_less(X_trans[2], [7, 8, 9])
