__version__ = '0.1.0'

from .divae import (
    VAE,
    AutoGMM,
    Evidence,
    DiVAE,
)
