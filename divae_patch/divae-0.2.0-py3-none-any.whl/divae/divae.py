import enum

import gin
import numpy as np
import tensorflow as tf
from divik.cluster import DiviK, GAPSearch, KMeans
from divik.feature_extraction import HistogramEqualization
from kneed import KneeLocator
from scipy.spatial.distance import cdist
from skimage.exposure import cumulative_distribution
from sklearn.base import BaseEstimator, ClusterMixin, TransformerMixin
from sklearn.mixture import GaussianMixture

import divae.vae as vae


@gin.configurable
class LearningRateScheduler:
    def __init__(self, epoch_max, lr_min, lr_max):
        self.epoch_max = epoch_max
        self.lr_min = lr_min
        self.lr_max = lr_max
        self._peak_epoch = epoch_max // 2
        self._lr_schedule_up = np.linspace(lr_min, lr_max, self._peak_epoch)
        self._lr_schedule_down = np.linspace(lr_max, lr_min, epoch_max - self._peak_epoch)
    
    def __call__(self, epoch, lr):
        if epoch < self._peak_epoch:
            return self._lr_schedule_up[epoch]
        return self._lr_schedule_down[epoch - self._peak_epoch]
    
    def as_callback(self):
        return tf.keras.callbacks.LearningRateScheduler(self)

    def __repr__(self):
        return f"LearningRateScheduler(epoch_max={self.epoch_max},lr_min={self.lr_min},lr_max={self.lr_max})"


@gin.configurable
class VAE(BaseEstimator, TransformerMixin):
    def __init__(self,
            intermediate_dim=512,
            latent_dim=5,
            epochs=100,
            batch_size=128,
            shuffle="batch",
            learning_rate=1e-3,
            learning_rate_schedule=None,
            equalize_histogram=False,
            verbose="auto",
            random_state=None,
            ):
        self.intermediate_dim = intermediate_dim
        self.latent_dim = latent_dim
        self.epochs = epochs
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.learning_rate = learning_rate
        self.learning_rate_schedule = learning_rate_schedule
        self.equalize_histogram = equalize_histogram
        self.verbose = verbose
        self.random_state = random_state
    
    def fit(self, X, y=None):
        if X.min() < 0:
            raise ValueError("data should not be negative")
        ncol = X.shape[1]
        X = X / X.sum(axis=1, keepdims=True)
        lr_schedule = self.learning_rate_schedule or LearningRateScheduler(
            epoch_max=self.epochs, lr_min=self.learning_rate, lr_max=self.learning_rate
        )
        vae_bn = vae.VAE_BN(ncol, self.intermediate_dim, self.latent_dim, self.random_state)
        self.vae_, self.encoder_ = vae_bn.get_architecture(
            verbose=self.verbose,
            lr=self.learning_rate,
        )
        self.history_ = self.vae_.fit(
            X,
            epochs=self.epochs,
            batch_size=self.batch_size,
            shuffle=self.shuffle,
            callbacks=[lr_schedule.as_callback()],
            # TODO: Fix verbosity https://keras.io/api/models/model_training_apis/
            verbose=self.verbose,
        )
        if self.equalize_histogram:
            _, _, X_trans = self.encoder_.predict(X)
            self.histogram_equalizer_ = HistogramEqualization().fit(X_trans)
        return self
    
    def transform(self, X, y=None):
        if X.min() < 0:
            raise ValueError("data should not be negative")
        X = X / X.sum(axis=1, keepdims=True)
        _, _, encoded = self.encoder_.predict(X)
        if self.equalize_histogram:
            encoded = self.histogram_equalizer_.transform(encoded)
        return encoded


def bayes_factor(bic_challenger, bic_champion):
    """Computes the evidence that the challenger model should replace champion

    BF < 0.5       - not worth more than a bare mention
    0.5 < BF < 1.0 - substantial
    1.0 < BF < 2.0 - strong
    2.0 < BF       - decisive
    """
    # np.log10(np.exp(-0.5 * (bic_challenger - bic_champion)))
    # the above overflows, so we change logarithm base
    return -0.5 * (bic_challenger - bic_champion) / np.log(10)


@gin.constants_from_enum
class Evidence(float, enum.Enum):
  Mention = 0.0
  Substantial = 0.5
  Strong = 1.0
  Decisive = 2.0


@gin.configurable
class AutoGMM(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        max_clusters=20,
        covariance_type="full",
        tol=1e-3,
        max_iter=100,
        n_init=1,
        method="bayes_factor",
        early_stopping=False,
        random_state=None,
        evidence:Evidence=Evidence.Decisive,
    ):
        self.max_clusters = max_clusters
        self.covariance_type = covariance_type
        self.tol = tol
        self.max_iter = max_iter
        self.n_init = n_init
        self.method = method
        self.early_stopping = early_stopping
        self.random_state = random_state
        self.evidence = evidence
        if self.method not in {"knee", "bayes_factor", "youden"}:
            raise ValueError(f"Unknown model selection method: {self.method}")

    def _select_knee(self, n_clusters):
        offset = 1
        self.n_clusters_ = KneeLocator(
            n_clusters,
            self.bic_,
            curve='convex',
            direction='decreasing'
        ).knee
        if self.n_clusters_ > np.argmin(self.bic_) + offset:
            self.n_clusters_ = np.argmin(self.bic_) + offset
        self.best_model_ = self.models_[self.n_clusters_ - offset]

    def _select_bayes_factor(self, n_clusters):
        self.n_clusters_ = 1
        self.best_model_ = self.models_[0]
        best_bic = self.bic_[0]
        for n, mdl, bic in zip(n_clusters, self.models_, self.bic_):
            if bayes_factor(bic, best_bic) >= self.evidence:
                best_bic = bic
                self.n_clusters_ = n
                self.best_model_ = mdl

    def _select_youden(self, n_clusters):
        """
        
        As per: https://en.wikipedia.org/wiki/Youden%27s_J_statistic

        """
        n1, y1 = 0, self.bic_[0]
        n2, y2 = len(self.bic_) - 1, self.bic_[-1]
        a = (y2 - y1) / (n2 - n1)
        b = y1
        y_mdl = a * np.arange(n2 + 1) + b
        J = np.abs(y_mdl - self.bic_)
        mdl_idx = np.argmax(J)
        self.n_clusters_ = n_clusters[mdl_idx]
        self.best_model_ = self.models_[mdl_idx]

    def _select_best(self, n_clusters):
        if self.method == 'knee':
            return self._select_knee(n_clusters)
        if self.method == 'bayes_factor':
            return self._select_bayes_factor(n_clusters)
        if self.method == 'youden':
            return self._select_youden(n_clusters)
        raise ValueError(f"Unknown model selection method: {self.method}")

    def fit(self, X, y=None):
        offset = 1
        n_clusters = list(range(offset, self.max_clusters + 1))
        if self.early_stopping:
            early_grace = int(self.early_stopping)
        else:
            early_grace = np.inf

        checked_clusters = []
        self.models_ = []
        self.bic_ = []

        last_bic = np.inf
        increasing_for = 0

        for n in n_clusters:
            mdl = GaussianMixture(
                n,
                tol=self.tol,
                max_iter=self.max_iter,
                n_init=self.n_init,
                covariance_type=self.covariance_type,
                random_state=self.random_state,
            ).fit(X)
            bic = mdl.bic(X)

            checked_clusters.append(n)
            self.models_.append(mdl)
            self.bic_.append(bic)

            if last_bic < bic:
                increasing_for += 1
            else:
                increasing_for = 0

            if increasing_for >= early_grace:
                break
            
            last_bic = bic

        self._select_best(checked_clusters)
        
        assert self.n_clusters_ is not None
        self.labels_ = self.best_model_.predict(X)
        self.fitted_ = True
        return self
    
    def predict(self, X, y=None):
        return self.best_model_.predict(X)
    
    def fit_predict(self, X, y=None):
        return self.fit(X).labels_


class _DiviKWrapper(DiviK):
    def __init__(
        self,
        auto_gmm: AutoGMM,
        vae: VAE,
        minimal_size: int = None,
        rejection_size: int = None,
        rejection_percentage: float = None,
        n_jobs: int = None,
        verbose: bool = False,
    ):
        super(_DiviKWrapper, self).__init__(
            kmeans=auto_gmm,
            fast_kmeans=None,  # unused
            distance='euclidean',
            minimal_size=minimal_size,
            rejection_size=rejection_size,
            rejection_percentage=rejection_percentage,
            minimal_features_percentage=0.01,  # unused
            features_percentage=0.05,  # unused
            normalize_rows=False,
            neutral=None,  # unused
            use_logfilters=False,  # unused
            filter_type="gmm",  # unused
            n_jobs=n_jobs,
            verbose=verbose,
        )
        self.auto_gmm = auto_gmm
        self.vae = vae
    
    def _get_filter(self, path):
        return None
    
    def _needs_normalization(self):
        return False

    def _feature_selector(self, n_features):
        return self.vae


@gin.configurable
class DiVAE(BaseEstimator, ClusterMixin):
    def __init__(
        self,
        auto_gmm: AutoGMM,
        vae: VAE,
        minimal_size: int = None,
        rejection_size: int = None,
        rejection_percentage: float = None,
        random_state: int = 42,
        n_jobs: int = None,
        verbose: bool = False,
    ):
        super(DiVAE, self).__init__()
        self.auto_gmm = auto_gmm
        self.vae = vae
        self.minimal_size = minimal_size
        self.rejection_size = rejection_size
        self.rejection_percentage = rejection_percentage
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.verbose = verbose

    def fit(self, X, y=None):
        # for compatibility purposes
        self.auto_gmm.kmeans = None
        divik = _DiviKWrapper(
            auto_gmm=self.auto_gmm,
            vae=self.vae,
            minimal_size=self.minimal_size,
            rejection_size=self.rejection_size,
            rejection_percentage=self.rejection_percentage,
            n_jobs=self.n_jobs,
            verbose=self.verbose,
        )
        self.divik_ = divik.fit(X, y)
        self.result_ = divik.result_
        self.labels_ = divik.labels_
        self.paths_ = divik.paths_
        self.reverse_paths_ = divik.reverse_paths_
        self.centroids_ = divik.centroids_
        self.depth_ = divik.depth_
        self.n_clusters_ = divik.n_clusters_
        return self
    
    def predict(self, X, y=None):
        return self.divik_.predict(X)


def _intensity_distances(padded_cube, indices, x, y, metric):
    # [y, x, neighbourhood_size]
    padded_dist_cube = np.nan * np.zeros(padded_cube.shape[:2] + (indices[0].size,))
    y_nbr, x_nbr = indices[0].ravel(), indices[1].ravel()
    for x_, y_ in zip(x, y):
        padded_dist_cube[y_, x_] = cdist(
            padded_cube[y_, x_].reshape(1, -1),
            padded_cube[y_ + y_nbr, x_ + x_nbr],
            metric=metric,
        )
    return padded_dist_cube


def _average(padded_cube, weights, indices, x, y):
    averaged = np.nan * np.zeros(padded_cube.shape)
    y_nbr, x_nbr = indices[0].ravel(), indices[1].ravel()
    for x_, y_ in zip(x, y):
        averaged[y_, x_] = np.nansum(
            weights[y_, x_].reshape(-1, 1) * padded_cube[y_ + y_nbr, x_ + x_nbr],
            axis=0
        )
    return averaged


@gin.configurable
class SpatialSmoothing(BaseEstimator, TransformerMixin):
    """Bilateral filter for MSI data.
    
    See:
    Alexandrov, Theodore, and Jan Hendrik Kobarg. "Efficient spatial
    segmentation of large imaging mass spectrometry datasets with
    spatially aware clustering." Bioinformatics 27.13 (2011): i230-i238.

    Section: Spatially aware structure-adaptive clustering
    """
    def __init__(self, radius=3, metric='euclidean'):
        self.radius = radius
        self.metric = metric
        assert radius % 2 == 1

    def fit(self, X, y=None, xy=None):
        return self

    def transform(self, X, y=None, xy=None):
        if xy is None:
            raise ValueError("Parameter xy is required.")

        # Build data cube
        # Purposefully here, as we will reuse x and y
        x, y = xy.T
        # We do padding by radius here
        x = x - x.min() + self.radius
        y = y - y.min() + self.radius
        # [y, x, n_features] - Y are rows, we add padding immediately
        cube = np.nan * np.zeros((y.max() + self.radius + 1, x.max() + self.radius + 1, X.shape[1]))
        cube[y, x] = X

        # Algorithm 2

        # Eq. 2
        kernel_size = 2 * self.radius + 1
        sigma_spatial = kernel_size / 4
        # [2, kernel_size, kernel_size]
        indices = np.indices((kernel_size, kernel_size)) - self.radius
        # [kernel_size, kernel_size]
        distance_alpha_ij = np.exp(-(indices ** 2).sum(axis=0) / (2 * sigma_spatial ** 2))

        # Eq. 5
        # Comparing with
        # https://scikit-image.org/docs/stable/api/skimage.restoration.html#skimage.restoration.denoise_bilateral
        # they call sigma_color a lambda, we call it sigma_intensity
        
        intensity_dist = _intensity_distances(cube, indices, x, y, self.metric)

        # They have some hack for sigma_intensity
        # https://github.com/kuwisdelu/Cardinal/blob/master/src/spatial.cpp#L244
        sigma_intensity = (np.nanmax(intensity_dist) - np.nanmin(intensity_dist)) / 2

        # [y, x, neighbourhood_size = kernel_size ** 2]
        intensity_beta_ij = np.exp((-(intensity_dist ** 2)) / (2 * sigma_intensity ** 2))


        # Bilateral filter
        weights = distance_alpha_ij.reshape(1, 1, -1) * intensity_beta_ij
        normalization_factor = np.nansum(weights, axis=2, keepdims=True)
        norm_weights = weights / normalization_factor
        padded_averaged = _average(cube, norm_weights, indices, x, y)
        
        return padded_averaged[y, x]

    def fit_transform(self, X, y=None, xy=None):
        return self.transform(X, y, xy)
