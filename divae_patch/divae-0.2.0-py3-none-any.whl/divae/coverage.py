import logging
import os
from functools import partial
from itertools import product
from typing import Dict, List, NamedTuple, Tuple

import gin
import joblib
import numpy as np
from sklearn.metrics import adjusted_rand_score, f1_score, precision_score
import tqdm


def _sort_cluster_ids(ground_truth, partition, score=precision_score):
    cluster_ids = np.unique(partition)
    precision = partial(score, ground_truth)
    precision_val = [precision(partition == idx) for idx in cluster_ids]
    cluster_ids_order = np.argsort(precision_val)[::-1]
    sorted_cluster_ids = cluster_ids[cluster_ids_order]
    return sorted_cluster_ids


def _partial_partitions(partition, cluster_ids):
    current = np.zeros(partition.shape, dtype=np.bool)
    for idx in cluster_ids:
        current[partition == idx] = True
        yield current


def _partial_scores(ground_truth, partitions, score=f1_score):
    return np.array([score(ground_truth, partition) for partition in partitions])


ClusterMap = Dict[int, int]
Scores = Dict[str, float]
BinaryMatchedPartition = NamedTuple('BinaryMatchedPartition', [
    ('partition', np.ndarray),
    ('score', float),
    ('cluster_map', ClusterMap)
])
MatchedPartition = NamedTuple('MatchedPartition', [
    ('partition', np.ndarray),
    ('scores', Scores),
    ('cluster_map', ClusterMap)
])


def greedy_fit(ground_truth, partition) -> BinaryMatchedPartition:
    assert np.unique(ground_truth).size == 2, \
        "Only binary ground truth is supported"

    cluster_ids = _sort_cluster_ids(ground_truth, partition)
    partitions = _partial_partitions(partition, cluster_ids)
    scores = _partial_scores(ground_truth, partitions)
    best = np.argmax(scores)
    cluster_map = {
            cluster: int(idx <= best) for idx, cluster in enumerate(cluster_ids)
    }
    optimal_partition = np.array([cluster_map[idx] for idx in partition], dtype=np.bool)
    return BinaryMatchedPartition(
        partition=optimal_partition,
        score=scores[best],
        cluster_map=cluster_map
    )


_InvalidClusterMap = Dict[int, List[int]]


def _consolidate_mappings(gt_ids, approximations, mapped_ids) \
        -> Tuple[ClusterMap, _InvalidClusterMap]:
    mappings = {
        cluster: [
            target for target, match in zip(gt_ids, approximations)
            if match.cluster_map[cluster]
        ]
        for cluster in mapped_ids
    }
    valid = {
        key: int(value[0]) for key, value in mappings.items()
        if len(value) == 1
    }
    invalid = {key: value for key, value in mappings.items() if key not in valid}
    return valid, invalid


def _propose_missing_recommendations(invalid, gt_ids):
    return {
        key: value if value else gt_ids for key, value in invalid.items()
    }


def _validate_conflicts(score, partition, valid, invalid, reporter):
    if not invalid:
        return valid

    logging.info("Resolving conflicts.")
    logging.info("Creating feasible options space...")
    options_space = list(product(*invalid.values()))
    logging.info(f"Option space of size {len(options_space)}")
    best_score = -np.inf
    resolved = None
    mapping = {**valid}
    keys = invalid.keys()

    for option in reporter(options_space):
        mapping.update(zip(keys, option))
        matched_partition = np.vectorize(lambda label: mapping[label])(partition)
        option_score = score(matched_partition)

        if option_score > best_score:
            best_score = option_score
            resolved = {**mapping}


    if resolved is None:
        logging.error("No resolution found.")
        raise ValueError("No resolution found.")

    logging.info("Conflicts resolved.")
    return resolved


def multi_fit(ground_truth, partition, score=adjusted_rand_score,
              reporter=tqdm.tqdm) -> MatchedPartition:
    ground_truth = np.asarray(ground_truth)
    partition = np.asarray(partition)
    gt_ids = np.unique(ground_truth)
    mapped_ids = np.unique(partition)
    logging.info(f"Approximating {gt_ids.size} ground truth ROIs with "
                 f"{mapped_ids.size} clusters (binary mode).")
    approximations = [
        greedy_fit(ground_truth == idx, partition) for idx in reporter(gt_ids)
    ]
    valid, invalid = _consolidate_mappings(gt_ids, approximations, mapped_ids)
    invalid = _propose_missing_recommendations(invalid, gt_ids)
    logging.info(f"Obtained {len(valid)} valid mappings and {len(invalid)} "
                 "invalid ones.")
    logging.info(f"Valid mappings: {valid}")
    logging.info(f"Invalid mappings: {invalid}")
    score_approximation = partial(score, ground_truth)
    mapping = _validate_conflicts(score_approximation, partition, valid,
                                  invalid, reporter)
    optimal_partition = np.array([mapping[idx] for idx in partition], dtype=int)
    logging.info("Calculating quality scores.")
    scores = {
        'dice_{0}'.format(i): f1_score(ground_truth == i, optimal_partition == i)
        for i in gt_ids
    }
    scores[score.__name__] = score_approximation(optimal_partition)
    logging.info("Scores calculated.")
    return MatchedPartition(
        partition=optimal_partition,
        scores=scores,
        cluster_map=mapping
    )


def encode_labels(ground_truth):
    original_labels = np.unique(ground_truth)
    mapping = {label: i for i, label in enumerate(original_labels)}
    reverse_mapping = {i: label for i, label in enumerate(original_labels)}
    encoded = np.array([mapping[label] for label in ground_truth])
    return encoded, reverse_mapping


def decode_labels(labels, reverse_mapping):
    return np.array([reverse_mapping[label] for label in labels])


def decode_scores(reverse_mapping, scores):
    def map_key(key):
        if 'dice' not in key:
            return key
        cluster_id = int(key.split('_')[1])
        mapped = reverse_mapping[cluster_id]
        return f'dice {mapped}'
    return {map_key(k): v for k, v in scores.items()}
