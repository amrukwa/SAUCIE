from itertools import cycle

import numpy as np
import plotly.colors as cm
import plotly.express as px
import plotly.graph_objs as go
from plotly.subplots import make_subplots

from ..plot import color


def select_backend(func):
    class Helper:
        def __init__(self, *args, **kwargs):
            self.svg = func(*args, **kwargs, render_mode="svg")
            self.auto = func(*args, **kwargs, render_mode="auto")
            self.layout = self.svg.layout

        def write_image(self, *args, **kwargs):
            self.svg.write_image(*args, **kwargs)

        def write_html(self, *args, **kwargs):
            self.auto.write_html(*args, **kwargs)

        def update_layout(self, *args, **kwargs):
            self.auto.update_layout(*args, **kwargs)
            self.svg.update_layout(*args, **kwargs)
            self.layout = self.svg.layout

        def show(self):
            self.auto.show()

    return Helper


px.scatter = select_backend(px.scatter)
px.scatter_polar = select_backend(px.scatter_polar)
px.line = select_backend(px.line)
px.line_polar = select_backend(px.line_polar)


def _rgb_to_rgba(rgb):
    return rgb.replace("rgb(", "rgba(").replace(")", ",1)")


def _parse_colors(colors):
    if isinstance(colors, str):
        if colors == "Infinite":
            colors = color.colors()
        else:
            colors = cm.PLOTLY_SCALES[colors]
            colors = cm.colorscale_to_colors(colors)
    return colors


_DQ = 1e-15


def _make_colorscale(q, color, bg):
    return [
        [0.0, "rgba(255,255,255,0)"],
        [q - _DQ, "rgba(255,255,255,0)"],
        [q, color],
        [1.0, color],
    ]


def _contour(X, y, q: float = 0.5, colors="Infinite", bg="grey", precision=1):
    assert X.ndim == 2
    assert X.shape[1] == 2
    assert X.shape[0] == y.size
    assert 0 <= q <= 1

    y_set, y_cnt = np.unique(y, return_counts=True)
    colors = cycle(_parse_colors(colors))

    nbin = int(np.round(precision * np.power(X.shape[0], 0.25)))
    bg_traces = [
        go.Scatter(
            x=X[:, 0],
            y=X[:, 1],
            name="markers",
            mode="markers",
            legendgroup="markers",
            marker=dict(size=3, color="cyan"),
            opacity=0.5,
            visible="legendonly",
        ),
    ]
    traces = []

    for label, cnt, color in zip(y_set, y_cnt, colors):
        X_local = X[y == label, :]
        nbin = int(np.round(precision * np.power(X_local.shape[0], 0.25)))
        bg_traces.append(
            go.Histogram2dContour(
                x=X_local[:, 0],
                y=X_local[:, 1],
                name="baseline",
                colorscale=[[0, "rgba(255,255,255,0)"], [_DQ, bg], [1.0, bg]],
                showscale=False,
                showlegend=True,
                legendgroup="baseline",
                histnorm="density",
                line=dict(width=0),
                nbinsx=nbin,
                nbinsy=nbin,
            )
        )
        traces.append(
            go.Histogram2dContour(
                x=X_local[:, 0],
                y=X_local[:, 1],
                name="{0}".format(label),
                colorscale=_make_colorscale(q, color, bg),
                showscale=False,
                opacity=0.75,
                showlegend=True,
                legendgroup="{0}".format(label),
                histnorm="density",
                line=dict(width=0.5),
                nbinsx=nbin,
                nbinsy=nbin,
            )
        )

    traces = bg_traces + traces

    return traces


def contour(
    data, x, y, color, q: float = 0.5, colors="Infinite", bg="grey", precision=1
):
    return go.Figure(_contour(
        data[[x, y]].values, data[[color]].values.ravel(), q, colors, bg, precision
    ))


def contour_matrix(
    X, y, q: float = 0.5, colors="Infinite", bg="grey", precision=1
):
    fig = make_subplots(
        rows=X.shape[1], cols=X.shape[1], shared_xaxes=True, shared_yaxes=True,
        column_titles=[f"U{i}" for i in range(X.shape[1])],
        row_titles=[f"U{i}" for i in range(X.shape[1])],
    )
    legend_traces = set()
    for i in range(X.shape[1]):
        for j in range(X.shape[1]):
            traces = _contour(X[:, [i, j]], y.ravel(), q, colors, bg, precision)
            for trace in traces:
                if trace.legendgroup in legend_traces:
                    trace.showlegend = False
                # in specific row we have Y-Axis, in column X-Axis
                fig.add_trace(trace, row=j + 1, col=i + 1)
                legend_traces.add(trace.legendgroup)
    return fig
