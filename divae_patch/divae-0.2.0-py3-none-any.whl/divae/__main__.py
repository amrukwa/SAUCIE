import colorsys
import itertools
import logging
import os
from fractions import Fraction
from functools import partial
from typing import Dict

import gin
import numpy as np
import tensorflow as tf

# TODO: Fix this upstream
from divik._summary import merged_partition
from divik.core import (
    dump_gin_args,
    parse_args,
)
from divik.core.io import (
    save,
    saver,
    try_load_data,
    try_load_xy,
)
from divik.core._utils import (
    prepare_destination,
    setup_logger,
)
# TODO: Fix this upstream
from divik.feature_selection._exims._exims import as_image
from divik.feature_selection._exims._structness import structness
from knockknock import teams_sender
from polyaxon.tracking import Run
from skimage.color import label2rgb
from sklearn.base import clone

from divae.coverage import (
    encode_labels,
    multi_fit,
    decode_labels,
    decode_scores,
)
from divae.divae import SpatialSmoothing


########################################################################
# Notification
########################################################################
def notify(fn):
    webhook_url = os.environ.get("MSTEAMS_NOTIFY_URL", None)
    if webhook_url:
        return teams_sender(webhook_url=webhook_url)(fn)
    return fn


########################################################################
# Parameters loading from gin file
########################################################################
def startswith(s: str, vals):
    return any(s.startswith(v) for v in vals)


def parse_gin_line(line):
    lhs, rhs = line.split("=")
    lhs = lhs.strip().replace(".", "__").replace("/", "__")
    rhs = rhs.strip()
    if startswith(rhs, ["@", "%", '"', "'"]):
        rhs = rhs.replace('"', "").replace("'", "")
    elif startswith(rhs, ["\\", "[", "("]):
        pass
    elif rhs in ["True", "False"]:
        rhs = rhs == "True"
    elif "." in rhs:
        rhs = float(rhs)
    elif rhs == "None":
        rhs = None
    else:
        rhs = int(rhs)
    return lhs, rhs


def load_gin(stream):
    return {
        parse_gin_line(line)[0]: parse_gin_line(line)[1]
        for line in stream
        if "=" in line and not line.startswith("#")
    }


def get_loader(fname):
    if fname.lower().endswith(".gin"):
        return load_gin
    raise ValueError(f"Unsupported file format: {fname}")


def load(fname):
    loader = get_loader(fname)
    with open(fname) as infile:
        return loader(infile)


def load_values(fnames):
    vals = {}
    for fname in fnames:
        vals.update(**load(fname))
    return vals


########################################################################
# Data loading
########################################################################
@gin.configurable
def load_data(path=gin.REQUIRED):
    return try_load_data(path)


@gin.configurable
def load_xy(path=gin.REQUIRED):
    return try_load_xy(path)


@gin.configurable
def load_ground_truth(paths=gin.REQUIRED):
    NO_ROI = "other"
    roi_name = lambda p: os.path.splitext(os.path.split(p)[1])[0]
    ground_truth = None
    size = None

    for path in paths:
        roi = np.loadtxt(path, delimiter=',').astype(bool)
        name = roi_name(path)

        if ground_truth is None:
            size = roi.size
            ground_truth = np.array([NO_ROI] * size, dtype=object)
        elif roi.size != size:
            raise ValueError(f"ROI size mismatch: {path}")
        
        ground_truth[roi] = name
    
    return ground_truth


########################################################################
# Colors
########################################################################
def _get_fractions():
    """
    [Fraction(0, 1), Fraction(1, 2), Fraction(1, 4), Fraction(3, 4), Fraction(1, 8), Fraction(3, 8), Fraction(5, 8), Fraction(7, 8), Fraction(1, 16), Fraction(3, 16), ...]
    [0.0, 0.5, 0.25, 0.75, 0.125, 0.375, 0.625, 0.875, 0.0625, 0.1875, ...]
    """
    yield 0
    for k in itertools.count():
        i = 2 ** k
        for j in range(1, i, 2):
            yield Fraction(j, i)


_DEFAULT_SATURATIONS = [Fraction(6, 10)]
_DEFAULT_VALUES = [Fraction(8, 10), Fraction(5, 10)]


def _generate_hsv_neighbourhood(h):
    for s in _DEFAULT_SATURATIONS:
        for v in _DEFAULT_VALUES:
            yield (h, s, v)


def as_colormap_color(h, s, v):
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return r, g, b


def colors():
    fractions = _get_fractions()
    neighbors = map(_generate_hsv_neighbourhood, fractions)
    neighbors = itertools.chain.from_iterable(neighbors)
    for args in neighbors:
        yield as_colormap_color(*args)


########################################################################
# Result saving
########################################################################
@saver
def save_latent_ion_images(model, fname_fn, **kwargs):
    if 'xy' not in kwargs:
        return
    if 'embedded' not in kwargs:
        return
    
    logging.info("Saving latent ion images")

    import plotly.express as px
    from skimage.exposure import equalize_hist
    from sklearn.preprocessing import minmax_scale

    xy = kwargs['xy']
    xy_norm = xy - xy.min(axis=0)

    embedded = kwargs['embedded']

    embedded_norm = minmax_scale(embedded)
    for dim in range(embedded.shape[1]):
        img = np.zeros(xy_norm.max(axis=0) + 1) * np.nan
        for row, val in zip(xy_norm, embedded_norm[:,dim]):
            img[tuple(row)] = val
        img = img.T
        
        fig = px.imshow(img, color_continuous_scale='viridis')
        fig.write_image(fname_fn(f'top_level_latent_ion_image_{dim}_scaled.png'))
        fig.write_html(fname_fn(f'top_level_latent_ion_image_{dim}_scaled.html'))

        img_equalized = equalize_hist(img, mask=~np.isnan(img))

        fig = px.imshow(img_equalized, color_continuous_scale='viridis')
        fig.write_image(fname_fn(f'top_level_latent_ion_image_{dim}_equalized.png'))
        fig.write_html(fname_fn(f'top_level_latent_ion_image_{dim}_equalized.html'))


@saver
def save_latent_scatterplot(model, fname_fn, **kwargs):
    if 'embedded' not in kwargs:
        return
    
    logging.info("Saving latent scatterplot")

    embedded = kwargs['embedded']
    
    if model.result_ is None:
        labels = np.zeros((embedded.shape[0],), dtype=int)
    else:
        labels = model.result_.clustering.labels_
    
    import pandas as pd
    import plotly.express as px
    from divae.plot import contour_matrix

    cols = [f'U{i}' for i in range(embedded.shape[1])]
    df = pd.DataFrame(embedded, columns=cols)
    df['labels'] = labels
    df.sort_values(by='labels', inplace=True)
    df.labels = df.labels.astype('category')
    
    colors_ = [
        f"rgb({int(255*r)},{int(255*g)},{int(255*b)})"
        for _, (r,g,b) in zip(
            np.unique(labels), colors()
        )
    ]

    fig = px.scatter_matrix(
        df,
        dimensions=cols,
        color='labels',
        color_discrete_sequence=colors_,
        opacity=0.03,
    )
    fig.write_image(fname_fn(f'top_level_latent_scatter.png'))
    fig.write_html(fname_fn(f'top_level_latent_scatter.html'))

    fig = contour_matrix(embedded, labels)
    fig.write_image(fname_fn(f'top_level_latent_contour.png'))
    fig.write_html(fname_fn(f'top_level_latent_contour.html'))


def visualize(label, xy, shape=None):
    """Create RGB map of labels over with given coordinates"""
    x, y = xy.T
    if shape is None:
        shape = np.max(y) + 1, np.max(x) + 1
    y = y.max() - y
    label = label - label.min() + 1
    label_map = np.zeros(shape, dtype=int)
    label_map[y, x] = label
    colors_ = [np.array(c, dtype=float) for _, c in zip(np.unique(label), colors())]
    image = label2rgb(label_map, bg_label=0, colors=colors_)
    return image[::-1]


@saver
def save_top_level_partition_image(model, fname_fn, **kwargs):
    if 'xy' not in kwargs:
        return
    if model.result_ is None:
        return
    
    logging.info("Saving top level partition image")
    
    import skimage.io
    
    xy = kwargs['xy']
    label = model.result_.clustering.labels_
    img = visualize(label, xy)
    skimage.io.imsave(fname_fn("top_level_partition.png"), img)


@saver
def save_top_level_knee_plot(model, fname_fn, **kwargs):
    if model.result_ is None and 'embedded' not in kwargs:
        return
    if model.result_ is None:
        auto_gmm = clone(model.auto_gmm).fit(kwargs['embedded'])
    else:
        auto_gmm = model.result_.clustering

    logging.info("Saving top level knee plot")
    
    import matplotlib.pyplot as plt
    
    min_marker = dict(linestyle='',marker='o',markerfacecolor='orange',markeredgecolor='orange',markeredgewidth='2',markersize=10)
    n_components = list(range(1, len(auto_gmm.bic_) + 1))
    BIC_Scores = auto_gmm.bic_
    plt.plot(n_components, BIC_Scores,'-g')
    plt.plot(auto_gmm.n_clusters_, BIC_Scores[auto_gmm.n_clusters_-1], **min_marker)
    plt.xticks(n_components)
    plt.xlabel('Number of clusters')
    plt.ylabel('BIC score')
    plt.title('The suggested number of clusters = '+ np.str(auto_gmm.n_clusters_))
    plt.tight_layout()
    plt.savefig(fname_fn('top_level_knee_plot.png'), dpi=400, transparent=True, bbox_inches='tight')
    plt.close()


def save_json(path: str, obj: Dict):
    import json
    obj = {
        str(key): int(value) if isinstance(value, np.int64) else value
        for key, value in obj.items()
    }
    with open(path, 'w') as outfile:
        json.dump(obj, outfile, indent=2, sort_keys=True)


@saver
def save_roi_matching(model, fname_fn, **kwargs):
    if "roi_matching" not in kwargs:
        return

    logging.info("Saving ROI matching")

    save_csv = partial(np.savetxt, delimiter=', ')

    match = kwargs["roi_matching"]

    save_csv(fname_fn('encoded_gt.csv'), match["encoded_gt"], fmt='%i')
    save_csv(fname_fn('encoded_partition.csv'), match["encoded_partition"], fmt='%i')
    save_csv(fname_fn('decoded_partition.csv'), match["decoded_partition"], fmt='%s')
    save_json(fname_fn('reverse_mapping.json'), match["reverse_mapping"])
    save_json(fname_fn('encoded_cluster_map.json'), match["encoded_cluster_map"])
    save_json(fname_fn('cluster_map.json'), match["cluster_map"])
    save_json(fname_fn('encoded_scores.json'), match["encoded_scores"])
    save_json(fname_fn('scores.json'), match["scores"])


@saver
def save_matched_roi(model, fname_fn, **kwargs):
    if "roi_matching" not in kwargs:
        return
    if 'xy' not in kwargs:
        return

    logging.info("Saving matched ROI image")

    import skimage.io
    
    xy = kwargs['xy']
    label = kwargs['roi_matching']['encoded_partition']
    img = visualize(label, xy)
    skimage.io.imsave(fname_fn("top_level_matched_partition.png"), img)


########################################################################
# Experiment
########################################################################
@gin.configurable
def experiment(
    model=gin.REQUIRED,
    seed=gin.REQUIRED,
    enable_smoothing=gin.REQUIRED,
):
    np.random.seed(seed)
    tf.set_random_seed(seed)
    tf.get_logger().setLevel('ERROR')
    tf.logging.set_verbosity(tf.logging.ERROR)

    run = Run()
    destination = prepare_destination(
        run.get_outputs_path(),
        omit_datetime=True,
        exist_ok=True
    )
    dump_gin_args(destination)
    run.log_inputs(**load_values([os.path.join(destination, 'config.gin')]))
    setup_logger(destination, verbose=True)
    logging.info(str(model))
    
    data = load_data()
    run.log_data_ref("ion_expressions", content=data)

    xy = load_xy()
    run.log_data_ref("xy_coordinates", content=xy)

    ground_truth = load_ground_truth()
    run.log_data_ref("ground_truth", content=ground_truth)
    encoded_gt, reverse_mapping = encode_labels(ground_truth)

    smoother = SpatialSmoothing()

    # repeated dump just because the dataset locations are not tracked
    dump_gin_args(destination)
    run.log_inputs(**load_values([os.path.join(destination, 'config.gin')]))

    if enable_smoothing:
        logging.info("Smoothing the data")
        data = smoother.fit_transform(data, xy=xy)
        logging.info("Data smoothed")
    else:
        logging.info("Smoothing skipped")

    kwargs = {}

    model.fit(data)
    if model.result_ is not None:
        kwargs["embedded"] = model.result_.feature_selector.transform(data)

        partition = merged_partition(model.result_)

        fit = multi_fit(encoded_gt, partition)
        decoded_partition = decode_labels(fit.partition, reverse_mapping)
        decoded_cluster_map = {
            cluster: reverse_mapping[label]
            for cluster, label in fit.cluster_map.items()
        }
        scores = decode_scores(reverse_mapping, fit.scores)
        x, y = xy.T
        forward_exims = np.sum(structness(as_image(fit.partition, x, y).squeeze()))
        backward_partition = -fit.partition + fit.partition.max()
        backward_exims = np.sum(structness(as_image(backward_partition, x, y).squeeze()))
        exims_score = forward_exims + backward_exims
        scores["unbounded_exims_score"] = exims_score

        kwargs["roi_matching"] = {
            "encoded_gt": encoded_gt,
            "encoded_partition": fit.partition,
            "decoded_partition": decoded_partition,
            "reverse_mapping": reverse_mapping,
            "encoded_cluster_map": fit.cluster_map,
            "cluster_map": decoded_cluster_map,
            "encoded_scores": fit.scores,
            "scores": scores,
        }
        run.log_metrics(**kwargs["roi_matching"]["scores"])
    
    if not kwargs:
        kwargs = {"embedded": clone(model.vae).fit_transform(data)}

    save(model, destination, xy=xy, **kwargs)


@notify
def main():
    gin.bind_parameter('save_pickle.enabled', False)
    parse_args()
    experiment()


if __name__ == "__main__":
    main()

